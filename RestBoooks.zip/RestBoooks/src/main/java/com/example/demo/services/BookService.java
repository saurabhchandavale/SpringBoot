package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.BookRepository;
import com.example.demo.entities.Book;
@Component
public class BookService {
	@Autowired
	private BookRepository bookRepository;
//	private static List<Book> list = new ArrayList<>();
//	
//	static {
//		list.add(new Book(1,"Ek Samandar, Mere Andar","Sanjeev Joshi"));
//		list.add(new Book(2,"Assam’s Braveheart – Lachit Barphukan","Arup Kumar Dutta"));
//		list.add(new Book(3,"The World: A Family History","British historian Simon Sebag Montefiore"));
//	}
	
	public List<Book> getAll(){
		List<Book> list = (List<Book>) this.bookRepository.findAll();
		return list;
		
	}
	public Book getBookById(int id) {
		Book book = null;
		try {
		book = this.bookRepository.findById(id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return book;
	}
	
	public Book addBook(Book b) {
		Book result = bookRepository.save(b);
		return result;
	}
	public void deleteBook(int id) {
		// TODO Auto-generated method stub
//		list = list.stream().filter(book -> {
//			if(book.getId()!=id) return true;
//			else return false;
//		}).collect(Collectors.toList());
		bookRepository.deleteById(id);
		
	}
	public void editBook(Book book,int id) {
		// TODO Auto-generated method stub
//		list = list.stream().map(b ->{
//			if(b.getId() == id) {
//				b.setTitle(book.getTitle());
//				b.setAuthor(book.getAuthor());
//			}
//			return b;
//			}).collect(Collectors.toList());
		book.setId(id);
		bookRepository.save(book);
		
	}
}
