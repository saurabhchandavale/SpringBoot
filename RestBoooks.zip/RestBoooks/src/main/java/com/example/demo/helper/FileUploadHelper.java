package com.example.demo.helper;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.imageio.stream.FileImageOutputStream;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FileUploadHelper {
	
	//public final String UPLOAD_DIR ="C:\\Users\\Saurabh\\Documents\\workspace-spring-tool-suite-4-4.15.3.RELEASE\\RestBoooks\\src\\main\\resources\\static\\images";
	public final String UPLOAD_DIR =new ClassPathResource("static/images/").getFile().getAbsolutePath();
	
	public FileUploadHelper() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean uploadFile(MultipartFile p) {
		boolean f = false;
		
		try {
//			InputStream inp = p.getInputStream();
//			byte data[] = new byte[inp.available()];
//			inp.read(data);
//			
//			//write
//			FileOutputStream fos = new  FileOutputStream(UPLOAD_DIR + "\\" + p.getOriginalFilename());
//			fos.write(data);
			Files.copy(p.getInputStream(), Paths.get(UPLOAD_DIR + "\\" + p.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
//			fos.flush();
//			fos.close();
			f = true;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}

}
